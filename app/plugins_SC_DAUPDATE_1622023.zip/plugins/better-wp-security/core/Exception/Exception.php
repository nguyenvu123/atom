<?php

namespace iThemesSecurity\Exception;

interface Exception {

}
