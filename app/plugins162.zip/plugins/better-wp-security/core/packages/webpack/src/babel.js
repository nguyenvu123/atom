module.exports = {
	presets: [ '@wordpress/default' ],
	plugins: [
		[
			'@babel/plugin-transform-react-jsx',
			{
				pragma: 'createElement',
			},
		],
		'@babel/plugin-proposal-class-properties',
		'@babel/plugin-syntax-dynamic-import',
		'@babel/plugin-proposal-export-default-from',
		'@babel/plugin-proposal-throw-expressions',
	],
};
