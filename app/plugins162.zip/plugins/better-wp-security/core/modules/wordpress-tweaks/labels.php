<?php

return [
	'title' => __( 'WordPress Tweaks', 'better-wp-security' ),
];
