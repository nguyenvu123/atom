<?php

require_once __DIR__ . '/class-itsec-ipcheck.php';
$itsec_ip_check = new ITSEC_IPCheck();
$itsec_ip_check->run();
