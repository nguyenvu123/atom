<?php

return [
	'title' => __( 'Dashboard', 'better-wp-security' ),
];
