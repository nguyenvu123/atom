<?php

return [
	'title' => __( 'Privacy', 'better-wp-security' ),
];
