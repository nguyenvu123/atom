<?php

require_once( 'class-itsec-privacy.php' );
$itsec_privacy = new ITSEC_Privacy();
$itsec_privacy->run();
