<?php defined('ABSPATH') or die("you do not have access to this page!"); ?>

<a href="https://really-simple-ssl.com/knowledge-base-overview/" target="_blank" class="button button-rsssl-secondary"><?php _e("Documentation", "really-simple-ssl"); ?></a>
