<div class="rsssl-wizard-menu">
    <div class="rsssl-wizard-title"><h1><?php _e( "Installation", 'really-simple-ssl' ) ?></h1></div>
    <div class="rsssl-wizard-progress-bar">
        <div class="rsssl-wizard-progress-bar-value" style="width: {percentage-complete}%"></div>
    </div>
    {title}
    <div class="rsssl-wizard-menu-menus">
        {steps}
    </div>
</div>
