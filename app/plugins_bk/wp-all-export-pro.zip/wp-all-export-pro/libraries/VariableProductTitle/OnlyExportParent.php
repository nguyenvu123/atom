<?php

class VariableProductTitle_OnlyExportParent
{
    /** @var  string */
    protected $value;

    public function process(WP_Post $current, WP_Post $parent)
    {
    }
}