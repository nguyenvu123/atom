<?php

class WpaeMethodNotFoundException extends Exception
{

}